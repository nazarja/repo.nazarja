import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import urllib
import requests

#==============================# 

from helpers import Helpers

#==============================#

addon_handle = int(sys.argv[1])
addonPath = os.path.join(xbmc.translatePath('special://home'), 'addons', 'plugin.program.maintenance.helper')
homePath = xbmc.translatePath('special://home')
imagesPath = os.path.join(addonPath, 'resources', 'images')
thumbnailsPath = xbmc.translatePath('special://thumbnails')
packagesPath = xbmc.translatePath('special://home/addons/packages')
addonsPath = os.path.join(xbmc.translatePath('special://home'), 'addons')
addonsDataPath = os.path.join(xbmc.translatePath('special://home'), 'userdata', 'addon_data')
tempPath = xbmc.translatePath('special://temp')
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
icon = os.path.join(imagesPath, 'icon-round.png')
thumb = os.path.join(imagesPath, 'icon.png')
fanart = os.path.join(imagesPath, 'fanart.jpg')

#==============================#

class Menu:

    #==============================#
    
    @staticmethod
    def mainmenu():
        menu = [
            {'mode': '0', 'title': 'Delete Thumbnails', 'plot': 'Delete All Thumbnails, Posters And FanArt Files.', 'stats': Menu.getInfoStats(thumbnailsPath, 0), 'isFolder': False},
            {'mode': '1', 'title': 'Delete Packages', 'plot': 'Delete All Package Zips From Updated and Installed Addons', 'stats': Menu.getInfoStats(packagesPath, 1), 'isFolder': False},
            {'mode': '2', 'title': 'Delete Cache', 'plot': 'Delete All Your Cache Files', 'stats': Menu.getCacheStats(), 'isFolder': False},
            {'mode': '3', 'title': 'View Kodi Log File', 'plot': 'View Active Kodi Log File Or Old Kodi Log File', 'isFolder': False},
            {'mode': '4', 'title': 'Perform Speed Test', 'plot': 'Perform A Speed Test, A Small File Download Will Measure Your Network Speed', 'isFolder': False},
            {'mode': '5', 'title': 'File Viewer', 'plot': 'Quickly View Files', 'isFolder': False},
            {'mode': '6', 'title': 'System Information', 'plot': 'View System Information, IP Addresses And Directory Sizes', 'isFolder': True},
            {'mode': '7', 'title': 'Reload Skin', 'plot': 'Reload Current Active Skin', 'isFolder': False},
        ]

        for item in menu:
            Menu.addItem(item)
        
        Menu.endDir()
    
    #==============================#

    @staticmethod
    def sysinfomenu():
        text = ''
        try: external_ip = str(requests.get('https://api.ipify.org').text)
        except: external_ip = 'Unavailable'

        system_info = [
            ['External IP Address', external_ip],
            ['Internal IP Address', xbmc.getInfoLabel('Network.IPAddress')],
            ['Gateway Address', xbmc.getInfoLabel('Network.GatewayAddress')],
            ['Addons Directory Size', Helpers.getSizeAndEntriesOfDir(addonsPath)],
            ['Addons Data Directory Size', Helpers.getSizeAndEntriesOfDir(addonsDataPath)],
            ['Kodi Total Size', Helpers.getSizeAndEntriesOfDir(homePath)],
        ]

        for info in system_info:
            title = '[COLOR blue]%s[/COLOR]:  %s' % (info[0], info[1])
            Menu.addItem({'mode': 99, 'title': title, 'plot': info[1], 'isFolder': False})
        
        Menu.endDir()

    #==============================#

    @staticmethod 
    def endDir():
        return xbmcplugin.endOfDirectory(addon_handle)

    #==============================#

    @staticmethod
    def addDir(url, li, isFolder):
        return xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isFolder)

    #==============================#

    @staticmethod 
    def addItem(item):
        if 'stats' in item: item['title'] += item['stats']
        url = sys.argv[0] + '?' + urllib.urlencode({'mode': item['mode']})
        li = xbmcgui.ListItem(item['title'])
        li.setInfo(type='Video', infoLabels={'title': item['title'], 'plot': item['plot']})
        li.setArt({'icon': fanart, 'thumb': icon, 'poster': fanart})
        Menu.addDir(url, li, item['isFolder'])

    #==============================#

    @staticmethod
    def getInfoStats(path, mode):
        files_count = 0
        total_size = 0

        for root, dirs, files in os.walk(path):
            files_count += len(files)
            
            if files_count > 0:
                for file in files:
                    if file.split('.')[1] not in ['log', 'db', 'dat', 'socket']:
                        total_size += os.path.getsize(os.path.join(root, file))

        if mode == 0:
            return '  (%s images)  %s' % (Helpers.formatInt(files_count), Helpers.convertBytes(total_size))  
        elif mode == 1:
            return '  (%s zips)  %s' % (Helpers.formatInt(files_count), Helpers.convertBytes(total_size))
        elif mode == 2:
            return (files_count, total_size)

    #==============================#

    @staticmethod
    def getCacheStats():
        cache = Menu.getInfoStats(cachePath, 2)
        temp = Menu.getInfoStats(tempPath, 2)
        files_count = cache[0] + temp[0]
        total_size = cache[1] + temp[1]
        return '  %s' % (Helpers.convertBytes(total_size))

                  
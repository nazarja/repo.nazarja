import os
import math
import xbmc
import xbmcgui
import xbmcaddon

#==============================#

addon = xbmcaddon.Addon('plugin.program.maintenance.helper')
addon_id = addon.getAddonInfo('id')
addon_path = addon.getAddonInfo('path')
icon_path = imagesPath = os.path.join(addon_path, 'resources', 'images', 'icon.png')
logPath = os.path.join(xbmc.translatePath('special://logpath'), 'kodi.log')
oldLogPath = os.path.join(xbmc.translatePath('special://logpath'), 'kodi.old.log')
dialog = xbmcgui.Dialog()

#==============================#

class Helpers:

    #==============================#

    @staticmethod
    def convertBytes(size):
        if (size == 0):
            return '0B'

        suffex = ("B", "KB", "MB", "GB", "TB", "PB")
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size / p, 2)

        return '%s %s' % (s, suffex[i])

    #==============================#

    @staticmethod
    def getSizeAndEntriesOfDir(path):
        total_size = 0
        dirs_count = [name for name in os.listdir(path) if os.path.isdir(os.path.join(path, name))]
        for root, dirs, files in os.walk(path):
            for file in files:
                filepath = os.path.join(root, file)
                total_size += os.path.getsize(filepath)
                
        return '({}) folders  {}'.format(len(dirs_count), Helpers.convertBytes(total_size), )
    
    #==============================#

    @staticmethod
    def formatInt(count):
        return '{:,}'.format(count)

    #==============================#

    @staticmethod
    def refresh():
        return xbmc.executebuiltin('Container.Refresh')

    #==============================#

    @staticmethod
    def colorizeLine(line):
        line = line.replace('WARNING', '[COLOR yellow]WARNING[/COLOR]').replace('ERROR', '[COLOR red]ERROR[/COLOR]') 
        line = line.replace('NOTICE', '[COLOR pink]NOTICE[/COLOR]').replace('ERROR', '[COLOR red]ERROR[/COLOR]') 
        line = line.replace('-->', '[COLOR green]-->[/COLOR]').replace('<--', '[COLOR green]<--[/COLOR]') 
        return line

#==============================#

class LogViewer(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self.selection = kwargs['selection']
        self.reversed = True if addon.getSetting('ReverseLog') == 'true' else False
        self.filepath = None
        self.log = ''

    def onInit(self):
        if self.selection == 0:
            self.filepath = logPath
            self.getLog()
            self.showLog()
        elif self.selection == 1:
            self.filepath = oldLogPath
            self.getLog()
            self.showLog()
        elif self.selection == 2:
            self.filepath = logPath
            self.reversed = True
            self.getLog()
            self.getShowLastError()
            self.showLog()

    def getLog(self):
        if self.reversed:
            for line in reversed(open(self.filepath).readlines()):
                self.log += Helpers.colorizeLine(line)
        else:
            for line in open(logPath).readlines():
                self.log += Helpers.colorizeLine(line)

    def showLog(self):
        self.getControl(1).setText(self.log)
        self.setFocusId(99)

    def getShowLastError(self):
        start = self.log.find('[COLOR green]-->[/COLOR]End of Python script error report[COLOR green]<--[/COLOR]')
        end = self.log.find('[COLOR green]-->[/COLOR]Python callback/script returned the following error[COLOR green]<--[/COLOR]')
        length = len('[COLOR green]-->[/COLOR]Python callback/script returned the following error[COLOR green]<--[/COLOR]')
        if start == -1 or end == -1:
            dialog.notification('Maintenance Helper', 'No Error Found', icon_path, 3000)
            return self.close()
        else:
            self.log = self.log[start:end+length]

#==============================#

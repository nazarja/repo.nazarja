import os
import sys
import time
import requests
import xbmc
import xbmcgui
import xbmcaddon

#==============================#

addon = xbmcaddon.Addon('plugin.program.maintenance.helper')
addonPath = addon.getAddonInfo('path')
dataPath = os.path.join(addonPath, 'resources', 'data')

#==============================#

dialog = xbmcgui.Dialog()

#==============================#

class SpeedTest:

    def __init__(self, *args, **kwargs):
        self.filename = ''
        self.filepath = ''

    def confirmSpeedTest(self):
        if dialog.yesno('Speed Test', 'Perform Speed Test Now?', 'This Will Download A File To Test Your Speed.'):
            self.selectOption()
    
    #==============================#

    def selectOption(self):
        options = ['5MB', '10MB', '20MB', '50MB', '100MB']
        selection = dialog.select('Select File Size', options)
        url = 'http://ipv4.download.thinkbroadband.com:8080/%s.zip' % (options[selection])
        self.filename = options[selection] + '.zip'
        self.filepath = os.path.join(dataPath, options[selection] + '.zip')
        self.downloadFile(url)


    def downloadFile(self, url):
        with open(self.filepath, 'wb') as file:
            start_time = time.time()
            request = requests.get(url, stream=True)
            length = request.headers.get('content-length')
            download = 0

            progress = xbmcgui.DialogProgress()
            progress.create('Speed Test', " ", " ", " ")
            progress.update(0)
            percent = 0
            data = {
                'megabytes': [],
                'megabits': []
            }

            try:
                for chunk in request.iter_content(1024):
                    if progress.iscanceled():
                        percent = 100
                        progress.update(percent, str(percent))
                        progress.close()
                        break

                    download += len(chunk)
                    file.write(chunk)

                    percent = int(100 * int(download) / int(length))
                    bits = (download // (time.time() - start_time))
                    megabytes = round((bits / 1000000), 2)
                    megabits = round(((bits / 1000000) * 8), 2)

                    data['megabytes'].append(round(megabytes, 2))
                    data['megabits'].append(round(megabits, 2))

                    progress.update(
                        percent, 
                        'MegaBytes Per Second (mBs):  {}'.format(megabytes),
                        'MegaBits Per Second (mbps):  {}'.format(megabits),
                        'Please Wait ... {}% Completed'.format(str(percent))
                    )

                self.getResults(str(round(time.time() - start_time, 2)), data)
                self.cleanUp()

            except Exception, e: 
                percent = 100
                progress.update(percent)
                progress.close()
                xbmc.log(str(e))
                dialog.ok('Speed Test', 'There Was A Problem')

    #==============================#

    def getResults(self, time, data):
        a_megabytes = str(round(sum(data['megabytes']) / len(data['megabytes']),2))
        a_megabits = str(round(sum(data['megabits']) / len(data['megabits']),2))
        h_megabytes = str(round(max(data['megabytes']),2))
        h_megabits = str(round(max(data['megabits']),2))
        
        dialog.textviewer(
            'Speed Test Results', 
            '[COLOR blue]Average:[/COLOR]   MegaBytes (mBs):  [COLOR yellow]{}[/COLOR] |   MegaBits (mbps):  [COLOR yellow]{}[/COLOR]\n'.format(a_megabytes, a_megabits) +
            '[COLOR blue]Highest:[/COLOR]   MegaBytes (mBs):  [COLOR yellow]{}[/COLOR] |   MegaBits (mbps):  [COLOR yellow]{}[/COLOR]\n'.format(h_megabytes, h_megabits) +
            '[COLOR blue]Time:[/COLOR]   [COLOR yellow]{}[/COLOR] seconds'.format(time)
        )

    #==============================#

    def cleanUp(self):
        try: os.unlink(self.filepath)
        except: pass

        if os.path.exists(os.path.join(addonPath, self.filename)):
            try: os.unlink(os.path.join(addonPath, self.filename))
            except: pass

    #==============================#


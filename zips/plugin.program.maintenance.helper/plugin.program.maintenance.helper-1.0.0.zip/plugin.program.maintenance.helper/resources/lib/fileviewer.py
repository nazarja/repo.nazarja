import os
import sys
import xbmc
import xbmcgui
import xbmcaddon

#==============================#

addon = xbmcaddon.Addon('script.file.editor')
addon_id = addon.getAddonInfo('id')
addon_path = addon.getAddonInfo('path')
icon_path = imagesPath = os.path.join(addon_path, 'resources', 'images', 'icon.png')
dialog = xbmcgui.Dialog()

#==============================#


class FileViewer(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self.path = kwargs['path']
        self.filename = kwargs['filename']

    #==============================#

    def onInit(self):
        self.control = self.getControl(2)
        self.getControl(1).setLabel(self.filename)
        self.openFile()

    #==============================#

    def onClick(self, controlId):
        if controlId == 9001: self.close()
    
    #==============================#

    def openFile(self):
        try:
            content = ''
            with open(self.path, 'r') as file:
                for line in file.readlines():
                    content += line.replace(chr(9), '        ')
            self.control.setText(content) 

        except:
            self.exit()

    #==============================#

    def exit(self):
        dialog.notification('File Editor', 'There Was A Problem.')
        self.close()

    #==============================#

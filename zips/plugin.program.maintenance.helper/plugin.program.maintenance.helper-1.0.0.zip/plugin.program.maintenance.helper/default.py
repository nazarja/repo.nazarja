import os
import sys
import shutil
import glob
import xbmc
import xbmcgui
import xbmcaddon
import urlparse

#==============================#

from resources.lib.menu import Menu
from resources.lib.helpers import Helpers
from resources.lib.speedtest import SpeedTest
from resources.lib.helpers import LogViewer
from resources.lib.fileviewer import FileViewer

#==============================#

addon = xbmcaddon.Addon('plugin.program.maintenance.helper')
addonPath = addon.getAddonInfo('path')
iconPath = imagesPath = os.path.join(addonPath, 'resources', 'images', 'icon.png')
dataPath = os.path.join(addonPath, 'resources', 'data')
thumbnailsPath = xbmc.translatePath('special://thumbnails')
packagesPath = xbmc.translatePath('special://home/addons/packages')
databasePath = xbmc.translatePath('special://database')
tempPath = xbmc.translatePath('special://temp')
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')

#==============================#

dialog = xbmcgui.Dialog()
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)

#==============================#

def deleteThumbnails():
    error = False
    if '(0 images)' in xbmc.getInfoLabel('ListItem.Title'):
        dialog.ok('Maintence Helper', 'No Thumbnails To Delete.')
    else:
        if dialog.yesno('Delete All Thumbnails', 'Are You Sure?'):
            for root, dirs, files in os.walk(thumbnailsPath):
                if len(files) > 0:
                    try:
                        for file in files:
                            os.unlink(os.path.join(root, file))
                    except:
                        error = True
            try:
                os.unlink(os.path.join(databasePath,"Textures13.db"))
                shutil.copy2(os.path.join(dataPath,"Textures13.db"), databasePath)
            except IOError:
                error = True

            if error:    
                dialog.ok('Maintence Helper', 'There Was A Problem!')
            else:
                dialog.ok('Maintence Helper', 'All Done, Thumbnails Have Been Deleted.')
            Helpers.refresh()  

#==============================#

def deletePackages():
    error = False
    if '(0 zips)' in xbmc.getInfoLabel('ListItem.Title'):
        dialog.ok('Maintence Helper', 'No Packages To Delete.')
    else:
        if dialog.yesno('Delete All Packages', 'Are You Sure?'):
            for root, dirs, files in os.walk(packagesPath):
                if len(files):
                        try:
                            for f in files:
                                os.unlink(os.path.join(root, f))
                            for d in dirs:
                                shutil.rmtree(os.path.join(root, d))
                        except:
                            error = True

            if error:    
                dialog.ok('Maintence Helper', 'There Was A Problem!')
            else:
                dialog.ok('Maintence Helper', 'All Done, Packages Have Been Deleted.')
            Helpers.refresh()


#==============================#

def deleteCache():
    error = False
    if dialog.yesno('Maintenance Helper', 'Delete All Cache Files?'):
        cache_paths = [cachePath, tempPath]

        for path in cache_paths:
            for root, dirs, files in os.walk(path):
                if len(files):
                    try:
                        for f in files:
                            if f.split('.')[1] not in ['log', 'db', 'dat', 'socket']:
                                os.unlink(os.path.join(root, f))
                        for d in dirs:
                            if d not in ('temp', 'archive_cache'):
                                shutil.rmtree(os.path.join(root, d))
                    except:
                        error = True

        if error:
            dialog.ok('Maintence Helper', 'There Was A Problem!')
        else:
            dialog.ok('Maintence Helper', 'All Done, Cache Has Been Deleted.')
        Helpers.refresh()

#==============================#


def viewLogFile():
    options = ['kodi.log', 'kodi.old.log', 'last python error']
    selection = dialog.select('Select Log File', options)
    if selection is not -1:
        ui = LogViewer('logviewer.xml', addonPath, 'default', '1080i', True, selection=selection)
        ui.doModal()
        del ui

#==============================#

def speedTest():
    speed_test = SpeedTest()
    speed_test.confirmSpeedTest()

#==============================#

def fileViewer():
    default = xbmc.translatePath('special://home')
    filename = None
    path = None
    path = dialog.browse(1, 'Select File', 'files', '', False, False, default)
    if path != default:
        try: 
            filename = path.split('/')[-1]
            try:
                name = filename.split('.')
                if name[-1] not in ['py', 'js', 'json', 'xml', 'txt']:
                    dialog.ok('Filename', 'Please Select A Valid File To View.\n Either: .py | .js | .json | .txt | .xml')
                    sys.exit()
            except: sys.exit()
        except: sys.exit()

        if filename == None or filename == '': sys.exit()
        else:
            ui = FileViewer('fileviewer.xml', addonPath, 'default', '1080i', True, path=path, filename=filename)
            ui.doModal()
            del ui

#=====================#

def reloadSkin():
    xbmc.executebuiltin('ReloadSkin')

#==============================#

if mode is None: Menu.mainmenu()
elif mode[0] == '0': deleteThumbnails()
elif mode[0] == '1': deletePackages()
elif mode[0] == '2': deleteCache()
elif mode[0] == '3': viewLogFile()
elif mode[0] == '4': speedTest()
elif mode[0] == '5': fileViewer()
elif mode[0] == '6': Menu.sysinfomenu()
elif mode[0] == '7': reloadSkin()
elif mode[0] == '99': pass
else: sys.exit()

#==============================#



              
        
